package feladat02;


public class Edesseg {
    private String megnevezes;
    private int egysegar;
    private int darabszam;

    public Edesseg(String megnevezes, int egysegar, int darabszam) {
        this.megnevezes = megnevezes;
        this.egysegar = egysegar;
        this.darabszam = darabszam;
    }

    public int keszletErtek() {
        return egysegar * darabszam;
    }

    @Override
    public String toString() {
        return "Megnevezés: " + megnevezes + ", Egységár: " + egysegar + ", Darabszám: " + darabszam;
    }
}

public class Csokolade extends Edesseg {
    private int kakaotartalom;

    public Csokolade(String megnevezes, int egysegar, int darabszam, int kakaotartalom) {
        super(megnevezes, egysegar, darabszam);
        this.kakaotartalom = kakaotartalom;
    }

    @Override
    public String toString() {
        return super.toString() + ", Kakaótartalom: " + kakaotartalom;
    }
}

public class Cukorka extends Edesseg {
    private boolean toltott;

    public Cukorka(String megnevezes, int egysegar, int darabszam, boolean toltott) {
        super(megnevezes, egysegar, darabszam);
        this.toltott = toltott;
    }

    @Override
    public String toString() {
        return super.toString() + ", Töltött: " + (toltott ? "igen" : "nem");
    }
}
