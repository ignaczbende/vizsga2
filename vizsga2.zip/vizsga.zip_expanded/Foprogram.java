package feladat02;

public class Foprogram {

	public static void main(String[] args) {
		
		// ide kerüljön a tömb feltöltése majd a kiíratás:
		
	
        Edesseg[] edessegek = new Edesseg[3];
        edessegek[0] = new Edesseg("Süti", 300, 10);
        edessegek[1] = new Csokolade("Édes csoki", 500, 5, 70);
        edessegek[2] = new Cukorka("Drazsé", 100, 20, true);

        for (Edesseg edesseg : edessegek) {
            System.out.println(edesseg.toString() + ", Készletérték: " + edesseg.keszletErtek() + ", Típus: " + edesseg.getClass().getSimpleName());
        }
    }
}


	}

}
