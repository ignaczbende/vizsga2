package feladat04;

public class Rendeles {

	private String szallitoiAzonosito;
	private String megnevezes;
	private int mennyiseg;
	private int osszertek;
	private boolean surgos;
	


	public Rendeles(String[] csvSor) {


		
		
		        public Rendeles(String szallitoLevelAzonosito, String Megnevezes, int mennyiseg, int osszertek, boolean surgos) {
				this.szallitoLevelAzonosito = szallitoLevelAzonosito;
				this.Megnevezes = Megnevezes;
				this.mennyiseg = mennyiseg;
				this.osszertek = osszertek;
				this.surgos = surgos;
			
		
				
	}

	
}
