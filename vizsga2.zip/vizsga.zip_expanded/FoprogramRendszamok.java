package feladat03;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class FoprogramRendszamok {

	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Set<String> rendszamok = new HashSet<String>();
		
		
		String menupont = null;
		do {
			
			System.out.println("Válasszon menüpontot:");
			System.out.println("1. Adatfelvitel");
			System.out.println("2. Behajtás ellenőrzés");
			System.out.println("3. Kilépés");
			menupont = sc.nextLine();
			
			switch (menupont) {
			
			case "1":
				
				System.out.println(adatfelvitel(rendszamok)+" új rendszámot vitt fel a rendszerbe");				
				break;
				
			case "2":
				System.out.print("Adja meg a behajtani óhajtó autó rendszámát: ");
				String rendszam = sc.nextLine();
				if (behajthat(rendszamok,rendszam)) {
					
					System.out.println("Az autó behajthat a parkolóba!");
					
				}
				else {
					
					System.out.println("Az autó nem hajthat be a parkolóba!");

				}
				break;
				
			}
			
			
		}while(!menupont.equals("3"));
		
		// TODO Ide kerüljön  a statisztika kiíratása

		

        int rendszamokSzama = rendszamok.size();
        System.out.println("Összesen tárolt rendszámok száma: " + rendszamokSzama);
        System.out.println("Összesen beengedett autók száma: " + sikeresFelvitel);
        System.out.println("Összesen elutasított autók száma: " + (rendszamokSzama - sikeresFelvitel));



	}
	 private static int adatfelvitel(Set<String> rendszamok) {
		
		int ujRendszamokDarabszam = 0;
		
		// TODO Ide kerüljön adatfelvitel megvalósítása, feladatkiírásnak megfelelően
		
	
        boolean kilepes = false;
        int sikeresFelvitel = 0;

        while (!kilepes) {
            System.out.println("Kérem adja meg a rendszámot (VÉGE a kilépéshez): ");
            String rendszam = scanner.nextLine();

            if (rendszam.equalsIgnoreCase("VÉGE")) {
                kilepes = true;
            } else {
                if (rendszamok.add(rendszam)) {
                    sikeresFelvitel++;
                } else {
                    System.out.println("A rendszám már szerepel az adatok között.");
                }
            }
        }

        System.out.println("Sikeresen felvitt rendszámok száma: " + sikeresFelvitel);
    


		 
		
		
		return ujRendszamokDarabszam;
		
	}



	public static boolean behajthat(Set<String> rendszamok, String rendszam) {
						
		return false;			
		
	}

}
